// //util.js


// var util = {};


// // 로그인 되었는가?
// isLogIn = function(req, res){
//   if(req.session.is_logined){
//     return true
//   } 
//   else { 
//     return false
//   }
// }


// module.exports = {
//   isLogIN : isLogIn,
//   redisClient : redisClient
// }