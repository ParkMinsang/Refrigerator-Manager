## Recipe 페이지

- Material - Ui 활용
- 사진은 랜덤으로 매번 바뀌도록 함



### 1. 메인화면 (데모)

![레시피(메인) 데모](Readme.assets/레시피(메인) 데모.PNG)

### 2. 검색결과 화면 (데모)

![레시피(검색) 데모](Readme.assets/레시피(검색) 데모.PNG)



