## Auth 페이지

- Material - Ui 활용
- 사진은 랜덤으로 매번 바뀌도록 함
- 아이디 중복 방지를 위해 SignUp에서는 이메일 확인부분 넣어줌



### 1. SignIn

![Signin](Readme.assets/Signin.png)



### 2. Signup

![SignUp](Readme.assets/SignUp.PNG)



